import React from 'react';

export const CollapseContext = React.createContext();
